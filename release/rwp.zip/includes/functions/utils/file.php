<?php

/**
 * ============================================================================
 * RIESTER file [@TODO Fill out summary for file.php (no period for file headers)]
 *
 * [@TODO Fill out description for file.php. (use period)]
 *
 * @link [@TODO Fill out url]
 *
 * @package    WordPress
 * @subpackage RIESTER
 * @since      RIESTER 0.1.0
 * ==========================================================================
 */

use RWP\Vendor\Exceptions\IO\Filesystem\FileNotFoundException;
use RWP\Vendor\Exceptions\Http\HttpException;
use RWP\Helpers\Str;


if ( ! class_exists( 'RWP\Helpers\Str' ) ) {
	require_once RWP_PLUGIN_ROOT . 'includes/core/helpers/Str.php';
}

/**
 * Only adds a trailing slash if the string does not already have one
 *
 * @param  string $string
 * @return string
 */

function rwp_trailingslashit( $string ) {
	if ( empty( $string ) ) {
		return $string;
	}
	if ( ! Str::endsWith( $string, DIRECTORY_SEPARATOR ) ) {
		$string = Str::finish( $string, DIRECTORY_SEPARATOR );
	}

	return wp_normalize_path( $string );
}

/**
 * Get the name of a file without the extension
 *
 * @param  mixed $string
 * @return string
 */

function rwp_basename( $string ) {
	$ext = pathinfo( $string, PATHINFO_EXTENSION );
	$string = wp_basename( $string, ".$ext" );

	return $string;
}

/**
 * Get the file extension
 *
 * @param string $file
 * @return string
 */

function rwp_file_ext( $file ) {
	return pathinfo( $file, PATHINFO_EXTENSION );
}

/**
 * @param string $dir
 * @param string $path_replace
 * @return string
 */
function rwp_standard_dir( $dir, $abspath = '', $path_replace = null ) {

	$dir = rwp_normalize_path( $dir );

	if ( is_string( $path_replace ) ) {
		if ( ! empty( $abspath ) ) {
			$abspath = rwp_normalize_path( ABSPATH );
			$contentpath = rwp_normalize_path( dirname( WP_CONTENT_DIR ) . '/' );
		}
		$dir = str_replace(array(
			$abspath,
			$contentpath,
		), $path_replace, $dir);
	}

	return $dir;
}

/**
 * @param string $path
 * @return string
 */
function rwp_normalize_path( $path ) {
	if ( function_exists( 'wp_normalize_path' ) ) {
		$path = wp_normalize_path( $path );
	} else {
		$path = str_replace( '\\', '/', $path );
		$path = str_replace( '//', '/', $path );
	}

	return $path;
}


/**
 * Access the WordPress Filesystem class
 *
 * @return WP_Filesystem_Direct
 */

function rwp_filesystem() {
	/**
	 * @var WP_Filesystem_Direct $wp_filesystem WordPress filesystem subclass.
	 */

	global $wp_filesystem;

	include_once ABSPATH . '/wp-admin/includes/file.php';
	WP_Filesystem();

	return $wp_filesystem;
}

/**
 * Does the file exist
 *
 * @param string $filepath The file path to check
 *
 * @throws FileNotFoundException
 *
 * @return bool
 */

function rwp_file_exists( $filepath ) {
	try {
		if ( rwp_filesystem()->exists( $filepath ) ) {
			return true;
		} else {
			throw new FileNotFoundException( wp_sprintf( 'File named %s not found in %s', basename( $filepath ), dirname( $filepath ) ) );
		}
	} catch ( FileNotFoundException $e ) {
		rwp_qm_log( $e->getMessage(), 'error' );
	}
	return false;
}

/**
 * Get file
 *
 * @param string $filename The file name or array of file names to include
 * @param string $dir      The sub-directory to look in
 * @param string $base     The folder to start searching from.
 *
 * @return string|false
 *
 * @throws FileNotFoundException
 */

function rwp_find_file( $filename, $dir = '', $base = __DIR__ ) {
	$base = rwp_trailingslashit( $base ); // only adds slash if it isn't already there

	$folder = $base . $dir;
	$folder = rwp_filesystem()->find_folder( $folder );

	if ( $folder ) {
		$folder = rwp_trailingslashit( $folder );
		$filepath = $folder . $filename;
		if ( rwp_file_exists( $filepath ) ) {
			return $filepath;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

/**
 * Get plugin file
 *
 * @param string $filename The file name or array of file names to include
 * @param string $dir      The sub-directory to look in
 *
 *
 * @return string|false
 */

function rwp_find_plugin_file( $filename, $dir = '' ) {
	return rwp_find_file( $filename, $dir, RWP_PLUGIN_ROOT );
}

/**
 * Get file
 *
 * @param mixed  $filename The file name or array of file names to include (does not need .php at the end)
 * @param string $dir      The sub-directory to look in (starting in root of plugin)
 * @param string $base     The folder to start searching from.
 * @param bool   $require  True to require the file/false to include the file
 * @param bool   $once     Require/include the file only once
 *
 * @throws FileNotFoundException
 *
 * @return mixed
 */

function rwp_get_file( $filename, $dir = '', $base = __DIR__, $require = false, $once = false ) {
	if ( is_string( $filename ) ) {
		$file = '';
		$filename = Str::before( $filename, '?' );
		$type = pathinfo( $filename, PATHINFO_EXTENSION );
		if ( filter_var( $filename, FILTER_VALIDATE_URL ) == false ) {
			$filename = rwp_find_file( $filename, $dir, $base );
			if ( $filename ) {

				if ( 'php' === $type ) {
					if ( $require ) {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					} else {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					}
				} elseif ( 'css' === $type || 'js' === $type || 'json' === $type ) {
					$file = rwp_get_file_data( $filename, true );
				} else {
					$file = $filename;
				}
			}
		} else {
			$file = rwp_get_file_data( $filename );
		}

		return $file;
	} elseif ( is_array( $filename ) ) {
		$files = $filename;

		foreach ( $files as $file ) {
			rwp_get_file( $file, $dir, $base, $require, $once );
		}
	}
}

/**
 * Get file
 *
 * @param mixed  $filename The file name or array of file names to include (does not need .php at the end)
 * @param string $dir      The sub-directory to look in (starting in root of plugin)
 * @param bool   $require  True to require the file/false to include the file
 * @param bool   $once     Require/include the file only once
 *
 * @throws FileNotFoundException
 *
 * @return mixed
 */

function rwp_get_plugin_file( $filename, $dir = '', $require = false, $once = false ) {
	if ( is_string( $filename ) ) {
		$file = '';
		$type = pathinfo( $filename, PATHINFO_EXTENSION );
		if ( filter_var( $filename, FILTER_VALIDATE_URL ) == false ) {
			$filename = rwp_find_plugin_file( $filename, $dir );
			if ( $filename ) {

				if ( 'php' === $type ) {
					if ( $require ) {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					} else {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					}
				} elseif ( 'css' === $type || 'js' === $type ) {
					$file = rwp_get_file_data( $filename, true );
				} else {
					$file = $filename;
				}
			}
		} else {
			$file = rwp_get_file_data( $filename );
		}

		return $file;
	} elseif ( is_array( $filename ) ) {
		$files = $filename;

		foreach ( $files as $file ) {
			rwp_get_plugin_file( $file, $dir, $require, $once );
		}
	}
}

/**
 * Get file
 *
 * @param mixed  $filename The file name or array of file names to include (does not need .php at the end)
 * @param string $dir      The sub-directory to look in (starting in root of plugin)
 * @param bool   $require  True to require the file/false to include the file
 * @param bool   $once     Require/include the file only once
 *
 * @throws FileNotFoundException
 *
 * @return mixed
 */

function rwp_get_dependency_file( $filename, $dir = '', $require = false, $once = false ) {
	if ( is_string( $filename ) ) {
		$file = '';
		$base_dir = 'dependencies/';
		if ( ! empty( $dir ) ) {
			$dir = rwp_add_suffix( $base_dir, $dir );
			$dir = wp_normalize_path( $dir );
		} else {
			$dir = $base_dir;
		}
		$dir = rwp_trailingslashit( $dir );
		$type = pathinfo( $filename, PATHINFO_EXTENSION );
		if ( filter_var( $filename, FILTER_VALIDATE_URL ) == false ) {
			$filename = rwp_find_plugin_file( $filename, $dir );
			if ( $filename ) {

				if ( 'php' === $type ) {
					if ( $require ) {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					} else {
						if ( $once ) {
							$file = include_once $filename;
						} else {
							$file = include $filename;
						}
					}
				} elseif ( 'css' === $type || 'js' === $type ) {
					$file = rwp_get_file_data( $filename, true );
				} else {
					$file = $filename;
				}
			}
		} else {
			$file = rwp_get_file_data( $filename );
		}

		return $file;
	} elseif ( is_array( $filename ) ) {
		$files = $filename;

		foreach ( $files as $file ) {
			rwp_get_plugin_file( $file, $dir, $require, $once );
		}
	}
}

/**
 * Simplified wrapper for getting file data
 *
 * @param string $url
 * @param bool   $local  Whether the url is a local path
 * @param string $output The output type
 *
 * @throws HttpException
 * @throws JsonException
 *
 * @return mixed|false
 */

function rwp_get_file_data( $url, $local = false, $output = 'OBJECT' ) {
	$url  = esc_url_raw( $url );
	$data = null;
	$type = pathinfo( $url, PATHINFO_EXTENSION );
	$is_array = ( 'ARRAY' === $output );

	if ( $local ) {
		if ( rwp_file_exists( $url ) ) {
			$data = rwp_filesystem()->get_contents( $url );
		}
	} else {
		$response = wp_safe_remote_get( $url );
		try {
			if ( ! is_wp_error( $response ) ) {
				$data = wp_remote_retrieve_body( $response );
			} else {
				$code = $response->get_error_code();
				$message = $response->get_error_message( $code );
				throw new Exception( $message, $code );
			}
		} catch ( Exception $e ) {
			rwp_qm_log( $e->getMessage(), 'error' );
		}
	}

	if ( 'json' === $type ) {
		try {
			if ( ! empty( $data ) ) {
				$data = json_decode( $data, $is_array, 512, JSON_THROW_ON_ERROR );

				if ( filled( $data ) ) {
					return $data;
				}
			}
		} catch ( JsonException $e ) {
			rwp_qm_log( $e->getMessage(), 'error' );
		}
	} else {
		return $data;
	}
}
