# assets directory

Use this directory to store asset files such as CSS, JS and images.

This directory can be removed if not used.
