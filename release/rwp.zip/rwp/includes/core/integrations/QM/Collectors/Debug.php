<?php

/** ============================================================================
 * Debug
 *
 * @package   RWP\Integrations\QM\Collectors
 * @since     0.9.0
 * @author    RIESTER <wordpress@riester.com>
 * @copyright 2020 - 2021 RIESTER Advertising Agency
 * @license   GPL-2.0+
 * ========================================================================== */

namespace RWP\Integrations\QM\Collectors;

class Debug extends Collector {
}
